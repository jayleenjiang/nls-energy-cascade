# Availability path audit

Generated: `2026-07-06T03:50:59.099412+00:00`

Draft: `Paper/revision_2026-06-19/draft.tex`

## Summary

- Total paths checked: 43
- Missing paths: 0
- Untracked files among existing file paths: 0

## Path records

| Kind | Manuscript path | Resolved path | Rule | Status | Git-tracked | SHA-256 |
|---|---|---|---|---|---:|---|
| availability | `flux/NLS_flux_canonical.cpp` | `flux/NLS_flux_canonical.cpp` | repo-root-relative | PASS (file) | yes | 76f937608280 |
| availability | `flux/analyze_canonical_flux.py` | `flux/analyze_canonical_flux.py` | repo-root-relative | PASS (file) | yes | a1aef076dc27 |
| availability | `flux/analyze_current_windows.py` | `flux/analyze_current_windows.py` | repo-root-relative | PASS (file) | yes | cc1e02ebc9d9 |
| availability | `flux/gibbs_mcmc_reference.py` | `flux/gibbs_mcmc_reference.py` | repo-root-relative | PASS (file) | yes | 3b443bc83012 |
| availability | `flux/compare_gibbs_sde.py` | `flux/compare_gibbs_sde.py` | repo-root-relative | PASS (file) | yes | afba16a25bd6 |
| availability | `Paper/revision_2026-06-19/scripts/analyze_flux_scaling_sensitivity.py` | `Paper/revision_2026-06-19/scripts/analyze_flux_scaling_sensitivity.py` | repo-root-relative | PASS (file) | yes | ef479273a910 |
| availability | `Paper/revision_2026-06-19/experiments/flux_validation/` | `Paper/revision_2026-06-19/experiments/flux_validation` | repo-root-relative | PASS (directory) | n/a |  |
| availability | `Paper/revision_2026-06-19/experiments/flux_validation/larger_n60_pilot_2026-06-20/flux_scaling_sensitivity_n10_60.json` | `Paper/revision_2026-06-19/experiments/flux_validation/larger_n60_pilot_2026-06-20/flux_scaling_sensitivity_n10_60.json` | repo-root-relative | PASS (file) | yes | 19315bf86b68 |
| availability | `Paper/revision_2026-06-19/report_assets/canonical_flux_distribution.pdf` | `Paper/revision_2026-06-19/report_assets/canonical_flux_distribution.pdf` | repo-root-relative | PASS (file) | yes | 5e62ab69ca55 |
| availability | `Paper/revision_2026-06-19/report_assets/canonical_flux_distribution_tail_summary.csv` | `Paper/revision_2026-06-19/report_assets/canonical_flux_distribution_tail_summary.csv` | repo-root-relative | PASS (file) | yes | 4937cb25c1c8 |
| availability | `Paper/revision_2026-06-19/experiments/flux_validation/parameter_robustness_2026-06-20/moderate_contrast_T8_T4_prod/b64_scaling_scaling.json` | `Paper/revision_2026-06-19/experiments/flux_validation/parameter_robustness_2026-06-20/moderate_contrast_T8_T4_prod/b64_scaling_scaling.json` | repo-root-relative | PASS (file) | yes | 059c81dc9203 |
| availability | `Paper/revision_2026-06-19/experiments/flux_validation/gamma_robustness_2026-06-21/gamma_robustness_scaling.json` | `Paper/revision_2026-06-19/experiments/flux_validation/gamma_robustness_2026-06-21/gamma_robustness_scaling.json` | repo-root-relative | PASS (file) | yes | 9cb11ab85325 |
| availability | `Paper/revision_2026-06-19/scripts/generate_manuscript_figures.py` | `Paper/revision_2026-06-19/scripts/generate_manuscript_figures.py` | repo-root-relative | PASS (file) | yes | 65026eb1d396 |
| availability | `Paper/revision_2026-06-19/manuscript_figure_metrics.json` | `Paper/revision_2026-06-19/manuscript_figure_metrics.json` | repo-root-relative | PASS (file) | yes | c0dfd2a21ffd |
| availability | `Paper/revision_2026-06-19/scripts/export_source_trace_metrics.py` | `Paper/revision_2026-06-19/scripts/export_source_trace_metrics.py` | repo-root-relative | PASS (file) | yes | ae824eaa3fca |
| availability | `Paper/revision_2026-06-19/source_trace_metrics.json` | `Paper/revision_2026-06-19/source_trace_metrics.json` | repo-root-relative | PASS (file) | yes | 3727e8adff98 |
| availability | `Paper/revision_2026-06-19/scripts/export_compare_residual_mesh_metrics.py` | `Paper/revision_2026-06-19/scripts/export_compare_residual_mesh_metrics.py` | repo-root-relative | PASS (file) | yes | b858f764ba7f |
| availability | `Paper/revision_2026-06-19/report_assets/compare_residual_mesh_metrics.json` | `Paper/revision_2026-06-19/report_assets/compare_residual_mesh_metrics.json` | repo-root-relative | PASS (file) | yes | b3d3dbab1b0f |
| availability | `Paper/revision_2026-06-19/scripts/recompute_short_chain_nn_metrics.py` | `Paper/revision_2026-06-19/scripts/recompute_short_chain_nn_metrics.py` | repo-root-relative | PASS (file) | yes | f403861b7a53 |
| availability | `Paper/revision_2026-06-19/short_chain_nn_rerun_metrics.json` | `Paper/revision_2026-06-19/short_chain_nn_rerun_metrics.json` | repo-root-relative | PASS (file) | yes | 5600a1a9f126 |
| availability | `Paper/revision_2026-06-19/scripts/analyze_eigen_fit_windows.py` | `Paper/revision_2026-06-19/scripts/analyze_eigen_fit_windows.py` | repo-root-relative | PASS (file) | yes | 4b7669683117 |
| availability | `Paper/revision_2026-06-19/eigen_fit_sensitivity.json` | `Paper/revision_2026-06-19/eigen_fit_sensitivity.json` | repo-root-relative | PASS (file) | yes | cdc0d3ecba77 |
| availability | `Paper/revision_2026-06-19/scripts/audit_manuscript_claims.py` | `Paper/revision_2026-06-19/scripts/audit_manuscript_claims.py` | repo-root-relative | PASS (file) | yes | 2791f8195678 |
| availability | `Paper/revision_2026-06-19/manuscript_claim_audit.json` | `Paper/revision_2026-06-19/manuscript_claim_audit.json` | repo-root-relative | PASS (file) | yes | d835fbd1cef6 |
| availability | `Paper/revision_2026-06-19/manuscript_claim_audit.md` | `Paper/revision_2026-06-19/manuscript_claim_audit.md` | repo-root-relative | PASS (file) | yes | 464a82d6ad07 |
| availability | `Paper/revision_2026-06-19/scripts/audit_availability_paths.py` | `Paper/revision_2026-06-19/scripts/audit_availability_paths.py` | repo-root-relative | PASS (file) | yes | 449c7c91c7d2 |
| availability | `Paper/revision_2026-06-19/availability_path_audit.json` | `Paper/revision_2026-06-19/availability_path_audit.json` | repo-root-relative | PASS (file) | yes |  |
| availability | `Paper/revision_2026-06-19/availability_path_audit.md` | `Paper/revision_2026-06-19/availability_path_audit.md` | repo-root-relative | PASS (file) | yes |  |
| availability | `Paper/revision_2026-06-19/references.bib` | `Paper/revision_2026-06-19/references.bib` | repo-root-relative | PASS (file) | yes | 0fa0283b6479 |
| availability | `Paper/revision_2026-06-19/integrity_audit_2026-06-19.md` | `Paper/revision_2026-06-19/integrity_audit_2026-06-19.md` | repo-root-relative | PASS (file) | yes | 2179f8666bb5 |
| figure | `action_profiles.pdf` | `Paper/revision_2026-06-19/action_profiles.pdf` | latex-source-relative | PASS (file) | yes | b72d9cafc37c |
| figure | `cascade_embedding.pdf` | `Paper/revision_2026-06-19/cascade_embedding.pdf` | latex-source-relative | PASS (file) | yes | ff8a00f7a6a3 |
| figure | `lte_residual_midchain.pdf` | `Paper/revision_2026-06-19/lte_residual_midchain.pdf` | latex-source-relative | PASS (file) | yes | 3785b901fca6 |
| figure | `report_assets/compare_residual_mesh.pdf` | `Paper/revision_2026-06-19/report_assets/compare_residual_mesh.pdf` | latex-source-relative | PASS (file) | yes | e2c7bff1ce9c |
| figure | `experiments/flux_validation/production_dt5e-4/flux_primary_scaling.pdf` | `Paper/revision_2026-06-19/experiments/flux_validation/production_dt5e-4/flux_primary_scaling.pdf` | latex-source-relative | PASS (file) | yes | c7c06317e77a |
| figure | `experiments/flux_validation/production_dt5e-4/current_windows_n40_windows.pdf` | `Paper/revision_2026-06-19/experiments/flux_validation/production_dt5e-4/current_windows_n40_windows.pdf` | latex-source-relative | PASS (file) | yes | c068514bde19 |
| figure | `experiments/flux_validation/production_dt5e-4/current_windows_variance_scaling.pdf` | `Paper/revision_2026-06-19/experiments/flux_validation/production_dt5e-4/current_windows_variance_scaling.pdf` | latex-source-relative | PASS (file) | yes | 976198b14d5a |
| figure | `eq_validation.png` | `Paper/revision_2026-06-19/eq_validation.png` | latex-source-relative | PASS (file) | yes | 3bc9927e20c1 |
| figure | `neq_density.png` | `Paper/revision_2026-06-19/neq_density.png` | latex-source-relative | PASS (file) | yes | 959983b2bbf6 |
| figure | `symmetry_breaking.png` | `Paper/revision_2026-06-19/symmetry_breaking.png` | latex-source-relative | PASS (file) | yes | 883ca0d5b778 |
| figure | `eigenvalue_scatter.png` | `Paper/revision_2026-06-19/eigenvalue_scatter.png` | latex-source-relative | PASS (file) | yes | 65215292c4d0 |
| figure | `Q1_slices.png` | `Paper/revision_2026-06-19/Q1_slices.png` | latex-source-relative | PASS (file) | yes | daa934ee72a1 |
| figure | `report_assets/canonical_flux_distribution.pdf` | `Paper/revision_2026-06-19/report_assets/canonical_flux_distribution.pdf` | latex-source-relative | PASS (file) | yes | 5e62ab69ca55 |

## Interpretation

This audit checks local path availability only.  It does not prove that
the GitHub branch, journal supplement, or archival DOI contains exactly
the same files unless rerun against that release artifact.
